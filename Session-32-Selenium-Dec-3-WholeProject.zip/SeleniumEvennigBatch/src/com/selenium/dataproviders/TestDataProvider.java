package com.selenium.dataproviders;

import org.testng.annotations.DataProvider;

public class TestDataProvider {
	
	@DataProvider(name = "logindata")
	public static Object[][] dataProviderForLogin()
	{
		//Object[][] obj = {{"admin","manager"},{"admin","manager"}};
		
		Object[][] obj = new String[2][2];
		
		obj[0][0] = "admin";
		obj[0][1] = "manager";
		obj[1][0] = "admin";
		obj[1][1] = "manager";
		
		return obj;
	}

}
