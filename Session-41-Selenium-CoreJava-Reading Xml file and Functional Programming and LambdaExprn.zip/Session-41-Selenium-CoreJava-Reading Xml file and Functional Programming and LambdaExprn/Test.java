package com.corejava.classes;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Test {

	public static void main(String[] args) throws Exception {
		
		
		//FunctionalProgram fp = new FPImplementation();
		//System.out.println(fp.addNumbers(10, 20));
		
		/*
		FunctionalProgram fp = new FunctionalProgram() {
			
			
			public int addNumbers(int a, int b) {
				return (a+b);
			}
		};
		
		System.out.println(fp.addNumbers(20, 30));
		
		*/
		
		FunctionalProgram testLambda = (a,b) -> (a+b);
		
		System.out.println(testLambda.addNumbers(30, 40));
		
		
		FunctionlInterface2 helloWorld = (a) -> a.length(); 
		
		System.out.println(helloWorld.printName("TestLambda"));
		
		
		//TesInterface.printName();
		
		//System.out.println(getObjectData("Home","Logout_Link"));

	}
	
public static String getObjectData(String PageElementTagName, String ElementName) throws Exception {		
		
		// To create the object of the DocumentBuilder factory ( entire document as object )
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		// To parse the entire document object in to child nodes.
		
		File f = new File("./objectdata.xml");
		Document document = builder.parse(f);
		
		Element root = 	document.getDocumentElement();			 // To fetch the root element in this case its element
		
		// Getting the List of all the nosed with the name "page"
		NodeList pages =	root.getElementsByTagName("page");
		
		// Looping through all the page nodes and get the name attribute of each page
		for(int i=0; i<pages.getLength(); i++) {
			
			Element pageobject = (Element)pages.item(i);						
			String pagename = pageobject.getAttribute("name"); 					
			
					// If the page name matches the page name supplied as argument then take that page as an object and leave other pages.
					if (pagename.equals(PageElementTagName))	{
						
						// Getting the list of all the child objects under the page chosen, and getting the name attribute 
						NodeList groups = pageobject.getElementsByTagName("uiobject");								
							
						for(int j=0; j<groups.getLength(); j++) {
							
								Element group = (Element)groups.item(j);
								String uiobjectname = group.getAttribute("name");
								
								// If the uiobject name matches the ElementName  supplied as argument then take that uiobject  as an object and leave other uiobjects.
								if (uiobjectname.equals(ElementName)){
									root.normalize();
									
									// Get the node value of the uiobject chosen ( which is the xpath in this case )
									String xpath = group.getFirstChild().getNodeValue();										
												
									// return  the xpath 
									return xpath;
									
									}			
							
								}
					}
			}
		return null;
	}

	
	

}
