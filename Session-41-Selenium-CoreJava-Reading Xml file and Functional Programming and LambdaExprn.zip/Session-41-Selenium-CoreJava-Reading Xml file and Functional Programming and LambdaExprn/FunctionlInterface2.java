package com.corejava.classes;

@FunctionalInterface
public interface FunctionlInterface2 {
	
	int printName(String s);

}
