package com.corejava.classes;

@FunctionalInterface
public interface FunctionalProgram {
	
	int addNumbers(int a, int b);

}
