package com.corejava.classes;

public interface TesInterface {
	
	int addNumbers(int a, int b);

}
