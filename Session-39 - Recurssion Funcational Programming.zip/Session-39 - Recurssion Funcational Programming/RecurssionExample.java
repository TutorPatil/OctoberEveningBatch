package com.corejava.classes;

public class RecurssionExample {
	
	public static void main(String[] args) {
		int fact = findFactorial(5);		
		System.out.println(fact);
	}
	
	
	public static void printNumbers(int x)
	{
		if( x >= 0)
		{
			printNumbers(x-1);
		}
		System.out.print(x+" ");
		
	}
	
	public static int findFactorial(int num)
	{
		if ( num <= 1)
			return 1;
		else
			return (num  * (findFactorial(num - 1)));
		
		
	}
	
	public static int getFactorial(int num)
	{
		int fact = 1;
		while ( num >= 1)
		{
			fact = (fact * num);
			num--;
			
		}
		
		return fact;
	}
	
	

}
