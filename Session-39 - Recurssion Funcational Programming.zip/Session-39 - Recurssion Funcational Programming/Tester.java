package com.corejava.classes;

public class Tester {

	public static void main(String[] args) {	
		
		/*
		TesInterface t = new TesInterface() {			
		
			public int addNumbers(int a, int b)
			{				
				return ( a+ b);
			}
		};
		
		System.out.println(t.addNumbers(20, 30));
		*/
		
		TesInterface t = (a, b)-> 
		{
		 	return (a+b);
		};
		
		
		System.out.println(t.addNumbers(20, 20));
	}
}
