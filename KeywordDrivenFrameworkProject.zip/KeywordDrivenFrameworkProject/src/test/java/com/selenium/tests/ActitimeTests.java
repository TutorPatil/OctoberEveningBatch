package com.selenium.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.library.CommonLibrary;



public class ActitimeTests extends BaseClass{
	
	
	
	@Test
	public static void runActitimeTests() throws IOException
	{	
		File file = new File("./src/test/data/ActitimeTestSuite.xlsx");
		FileInputStream fio = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fio);		
		XSSFSheet ws = wb.getSheet("suite");
		
		int rows = ws.getLastRowNum();
		
		
			
		for (int i=1;i<=rows;i++)
		{
			String testCase = ws.getRow(i).getCell(0).getStringCellValue();
			String status = ws.getRow(i).getCell(1).getStringCellValue();
			String description = ws.getRow(i).getCell(2).getStringCellValue();	
			
		try {
			
			if (status.equalsIgnoreCase("YES"))
			{
				writeLogs("The status for the test case "+testCase +" is set to YES, hence running this test case ");
				CommonLibrary.runTestCase(testCase,description);
			}
			else
			{
				writeLogs("The status for the test case "+testCase +" is set to NO, hence Skipping  this test case ");
			}
			
		}catch (Exception  e) {
			wb.close();
			e.printStackTrace();
			CommonLibrary.closeBrowser();
		}
								
		}			
		
		
	}

}
