package com.selenium.library;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.selenium.base.BaseClass;


public class CommonLibrary extends BaseClass{	
	

	public static void runTestCase(String testCase,String description) throws IOException
	{
		
		writeLogs(" Starting the test case "+testCase + "And the description is "+description);
		
		File f = new File("./src/test/data/"+testCase+".xlsx");		
		FileInputStream fio = new FileInputStream(f);		
		XSSFWorkbook wb = new XSSFWorkbook(fio);		
		XSSFSheet ws = wb.getSheet("sheet1");
		
		int rows = ws.getLastRowNum();
		
		
		for (int i=1;i<=rows;i++)
		{
			String keyword = ws.getRow(i).getCell(0).getStringCellValue();
			String testdescription = ws.getRow(i).getCell(1).getStringCellValue();
			String locator = ws.getRow(i).getCell(2).getStringCellValue();	
			String testData = ws.getRow(i).getCell(3).getStringCellValue();
			
			switch (keyword)
			{
				case "launchBorwser":
				{
					launchBrowserKeyword(testData);
					break;
				}
				
				case "EnterText_TextBox":
				{
					EnterText_TextBox(locator,testData);
					break;
				}
				case "Click_Button":
				{
					Click_Button(locator);
					break;
				}
				case "VerifyElementDisplayed":
				{			
				
					VerifyElementDisplayed(locator);
					break;
				}			
				case "CloseBrowser":
				{			
					closeBrowser();
					break;
				}			
				
		
		
	}
			
	}
		
			wb.close();		
	}
			

			public static void launchBrowserKeyword(String testurl) throws IOException	
				{
					System.out.println("This method will run before every Test");
					
					String browser = getConfigData("browser");
					String url = testurl;
					String  timeout = getConfigData("timeout");
					int tout = Integer.parseInt(timeout);
					
					
					if (browser.equals("chrome"))
					{
					System.setProperty("webdriver.chrome.driver", "./src/test/utilities/chromedriver.exe");
					
					 driver = new ChromeDriver();
					}
					else if (browser.equals("firefox"))
					{
						System.setProperty("webdriver.gecko.driver", "./src/test/utilities/geckodriver.exe");
						
						 driver = new FirefoxDriver();
									
					}
					else
					{
						System.out.println("Browser not supported");
					}
					
					//Implicit wait 					
					driver.manage().timeouts().implicitlyWait(tout, TimeUnit.SECONDS);
					
					driver.get(url);
					
					}

					
					public static void EnterText_TextBox(String locator,String data)
						{
						
							driver.findElement(By.xpath(locator)).sendKeys(data);
							
					
						}
					
					
					public static void Click_Button(String locator)
					{
						driver.findElement(By.xpath(locator)).click();
					
					}
					
					
					public static boolean VerifyElementDisplayed(String locator)
					{
						try {
							Thread.sleep(4000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						boolean status= driver.findElement(By.xpath(locator)).isDisplayed();
						
						return status;
						
					}
					
					public static void closeBrowser()
					{
						writeLogs(" This method will run after every @Test ");
						
						driver.close();
					}
	
	

}
