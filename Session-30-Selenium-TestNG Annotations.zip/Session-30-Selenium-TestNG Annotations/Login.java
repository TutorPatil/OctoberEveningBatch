package com.selenium.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.library.CommonLibrary;

public class Login extends BaseClass{
	
		
	@Test
	public static void login_001() throws Exception
	{
		
		System.out.println( " Starting the login_001 Test Case");
		String userName = getTestData("Login", "UserNameValid_EditBox");
		String password = getTestData("Login", "Password_EditBox");	
		
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		
		Assert.assertTrue(result, "Login_001 failed!!");
		writeResultsToFile("login_001", "Pass");
				
		System.out.println( " Ending the login_001 Test Case");
	}
	
	
	@Test
	private static void login_002() throws Exception
	{		
		System.out.println( " Starting the login_002 Test Case");
		
		String userName = getTestData("Login", "UserNameValid_EditBox");
		String password = getTestData("Login", "Password_EditBox");
		
	
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		result=false;
		
		Assert.assertTrue(result, "Login_002 Faild!!");
		
		System.out.println( " ending the login_001 Test Case");
		
	}

}
