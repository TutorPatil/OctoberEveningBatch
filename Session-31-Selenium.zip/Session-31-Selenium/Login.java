package com.selenium.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.library.CommonLibrary;

public class Login extends BaseClass{	
		
	//@Test(dependsOnGroups =  {"smoke"} , groups= {"regression","login","login_001"})
	
	//@Test(groups= {"regression","login","login_001"})
	//@Test
	public static void login_001() throws Exception
	{
		
		System.out.println( " Starting the login_001 Test Case");
		String userName = getTestData("Login", "UserNameValid_EditBox");
		String password = getTestData("Login", "Password_EditBox");	
		
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		
		Assert.assertTrue(result, "Login_001 failed!!");
		writeResultsToFile("login_001", "Pass");
				
		System.out.println( " Ending the login_001 Test Case");
	}
	
	
	//@Test(groups= {"smoke","login","login_002"})	
	//@Parameters({ "userName", "Password","salary" })
	//public static void login_002(String userName,String password,String sal) throws Exception
	
	
	@Test(dataProvider = "logindata")
	public static void login_002(String userName,String password) throws Exception
	{		
		System.out.println( " Starting the login_002 Test Case");
		
		//int sal1 = Integer.parseInt(sal);
		
		//System.out.println("Salray is ---" + sal1);
		
		//String userName = getTestData("Login", "UserNameValid_EditBox");
		//String password = getTestData("Login", "Password_EditBox");
		
	
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		//result=false;
		
		Assert.assertTrue(result, "Login_002 Faild!!");
		
		System.out.println( " ending the login_001 Test Case");
		
	}
	
	@DataProvider(name = "logindata")
	public static Object[][] dataProviderForLogin()
	{
		//Object[][] obj = {{"admin","manager"},{"admin","manager"}};
		
		Object[][] obj = new String[2][2];
		
		obj[0][0] = "admin";
		obj[0][1] = "manager";
		obj[1][0] = "admin";
		obj[1][1] = "manager";
		
		return obj;
	}

}
