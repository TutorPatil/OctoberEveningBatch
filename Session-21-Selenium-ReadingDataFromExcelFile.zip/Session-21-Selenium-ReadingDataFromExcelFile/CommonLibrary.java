package com.selenium;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CommonLibrary extends BaseClass{
	
	public static WebDriver driver = null;	
	
	
	public static void launchBrowser(String url)
	{
		System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
		
		driver = new ChromeDriver();		
		
		driver.get(url);
	}
	
	public static void launchBrowser()
	{
		
		String url = "https://demo.actitime.com";
		
		System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
		
		driver = new ChromeDriver();		
		
		driver.get(url);
	}
	
	public static void closeBrowser()
	{
		driver.quit();
	}
	
	public static boolean launchLoginToActiTime(String username, String password) throws Exception
	{
		launchBrowser();
		
		driver.findElement(By.xpath(getLocatorData("Login","UserName_EditBox"))).sendKeys("admin");
		
		driver.findElement(By.xpath(getLocatorData("Login","Password_EditBox"))).sendKeys("manager");
		
		driver.findElement(By.xpath(getLocatorData("Login","Ok_Button"))).click();
		
		Thread.sleep(5000);
		
		boolean result = driver.findElement(By.xpath(getLocatorData("Home", "Logout_Link"))).isDisplayed();
		
		return result;
		
	}


	
	

}
