package com.selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.google.common.io.Files;

public class BaseClass {

	
	public static WebDriver driver = null;	
	
	
	public static void launchBrowser(String url)
	{
		System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
		
		driver = new ChromeDriver();		
		
		driver.get(url);
	}
	
	public static void launchBrowser() throws IOException
	{
		
		String url = getConfigData("url");
		
		String browser = getConfigData("browser");
		
		if (browser.equalsIgnoreCase("chrome"))
		{
		
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");		
			driver = new ChromeDriver();
		
		}
		
		else if (browser.equalsIgnoreCase("firefox"))
		{
		
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");		
			driver = new FirefoxDriver();
		
		}
		
		driver.get(url);
	}
	
	public static void closeBrowser()
	{
		driver.quit();
	}
	
	public static void captureScreenshot(String fileName)
	
	{		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		File dest = new File("./results/"+fileName+".png");
			
		try {
			Files.copy(src, dest);
		} catch (IOException e) {			
			e.printStackTrace();
		}
		
		
	}
	
	public static String getConfigData(String key) throws IOException
	{
		String value = "";
		
		File f = new File("./data/config.properties");
		FileInputStream fis = new FileInputStream(f);
		
		Properties prop = new Properties();
		prop.load(fis);
		
		
		value = prop.getProperty(key);
		
		
		return value;	
		
	}
	
	
	public static String getLocatorData(String pageName, String elementName) throws IOException
	{
		String locator = "";		
		File f = new File("./data/locatordata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the Object of the WorkBook
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		//Getting the work sheet
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		//To fetch the number of used rows in the current sheet
		int rows = ws.getLastRowNum();
		System.out.println(" No of rows in the sheet "+rows);
		for (int i=1;i<=rows;i++)
		{
			String page = ws.getRow(i).getCell(0).getStringCellValue();
			String element = ws.getRow(i).getCell(1).getStringCellValue();
			
			if(pageName.equalsIgnoreCase(page) && elementName.equalsIgnoreCase(element))
			{
				 locator = ws.getRow(i).getCell(2).getStringCellValue();
				 break;			}					
		}		
		wb.close();		
		return locator;
	}

	public static String getTestData(String pageName, String elementName) throws IOException
	{
		String data = "";		
		File f = new File("./data/testdata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the Object of the WorkBook
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		//Getting the work sheet
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		//To fetch the number of used rows in the current sheet
		int rows = ws.getLastRowNum();
		System.out.println(" No of rows in the sheet "+rows);
		for (int i=1;i<=rows;i++)
		{
			String page = ws.getRow(i).getCell(0).getStringCellValue();
			String element = ws.getRow(i).getCell(1).getStringCellValue();
			
			if(pageName.equalsIgnoreCase(page) && elementName.equalsIgnoreCase(element))
			{
				data = ws.getRow(i).getCell(2).getStringCellValue();
				 break;			}					
		}		
		wb.close();		
		return data;
	}
	



}
