package com.selenium;

import java.io.IOException;

import org.openqa.selenium.By;

public class Selenium_Nov18_ReadingDataFromExcel extends BaseClass{
		
	public static void main(String[] args) throws Exception {
		
		String userNameData = getTestData("Login", "UserName_EditBox");
		String passwordData = getTestData("Login", "Password_EditBox");
		
		boolean result = CommonLibrary.launchLoginToActiTime(userNameData, passwordData);
		
		if (result)
		{
			System.out.println("Login_001 is Pass");
		}
		else
		{
			System.out.println("Login_001 is Failed!!");
		}
		
		
		
		
		
			
		
		
		
		
		
		

	}

}
