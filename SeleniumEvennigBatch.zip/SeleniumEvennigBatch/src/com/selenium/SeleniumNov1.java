package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumNov1 {
	
	static WebDriver driver = null;

	public static void main(String[] args) throws InterruptedException {
		
		locatorExamples();
	}
	
	public static void launchActitime()
	{
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
		
		driver = new ChromeDriver();		
		
		driver.get("https://demo.actitime.com");
	}
	
	public static void loginToActiTime(String username, String password) throws InterruptedException
	{
		
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys(username);
		
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys(password);
	
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		
		Thread.sleep(5000);
	}
	
	
	public static void closeBrowser()
	{
		driver.quit();
	}
	public static void getTextExample() throws InterruptedException
	{
		launchActitime();
		
		loginToActiTime("admin","manager123");
		
		String errorText = driver.findElement(By.xpath("//span[@class='errormsg']")).getText();
		
		/*
		if (driver.findElement(By.xpath("//span[text()='Username or Password is invalid. Please try again.']")).isDisplayed())
		{
			System.out.println("Pass");
		}
		*/

		
		System.out.println(errorText);
		
		if (errorText.equalsIgnoreCase("Username or Password is invalid. Please try again."))
		{
			System.out.println(" Invalid login Test Case 002 -- PASS");
		}
		else
		{
			System.out.println(" Invalid login Test Case 002 -- FAILED");
		}
		closeBrowser();
		
	}

	
	public static void getAttributeExample() throws InterruptedException
	{
		launchActitime();
		
		loginToActiTime("admin","manager123");
		
		WebElement errorText = driver.findElement(By.xpath("//span[text()='Username or Password is invalid. Please try again.']"));
		
		String attval = errorText.getAttribute("class");

		System.out.println(" The attribute value is "+ attval);
		
		closeBrowser();
		
	}

	
	public static void getAttributeExample2() throws InterruptedException
	{
		launchActitime();
		
		driver.get("https://flipkart.com");		
		
		WebElement errorText = driver.findElement(By.xpath("//img[@class='_1e_EAo']"));
		
		String attval = errorText.getAttribute("title");

		System.out.println(" The attribute value is "+ attval);
		
		closeBrowser();
		
	}
	
	public static void getAttributeExample3() throws InterruptedException
	{
		launchActitime();
		
		driver.get("file:///C:/Users/H/Desktop/Selenium_EveningBatch/login.html");		
		
		WebElement errorText = driver.findElement(By.xpath("//img[@src='seleniumlogo.png']"));
		
		String attval = errorText.getAttribute("title");

		System.out.println(" The attribute value is "+ attval);
		
		closeBrowser();
		
	}
	
	
	public static void getTagNameExample() throws InterruptedException
	{
		launchActitime();
		
		driver.get("file:///C:/Users/H/Desktop/Selenium_EveningBatch/login.html");		
		
		WebElement errorText = driver.findElement(By.xpath("//img[@src='seleniumlogo.png']"));
		
		String tagName = errorText.getTagName();

		System.out.println(" The Tag Name is "+ tagName);
		
		closeBrowser();
		
	}
	
	public static void differentLocatorsExamples() throws InterruptedException
	{
		launchActitime();
		
		driver.get("file:///C:/Users/H/Desktop/Selenium_EveningBatch/login.html");		
		
		WebElement errorText = driver.findElement(By.xpath("//input[@id='username']"));
		
		errorText.sendKeys("selenium");
		
		driver.findElement(By.id("username")).sendKeys("selenium");

		driver.findElement(By.id("pwd")).sendKeys("password");
		
		
		driver.findElement(By.name("username")).clear();
		
		driver.get("https://demo.actitime.com");
		
		
		driver.findElement(By.linkText("actiTIME Inc.")).getText();
		
		driver.findElement(By.xpath("//a[text()='actiTIME Inc.']")).getText();
		
		driver.findElement(By.xpath("//a[contains(text(),'actiTIME')]")).getText();
		
		driver.findElement(By.partialLinkText("actiTIME")).getText();
		
		closeBrowser();
		
	}
	
	
	public static void locatorExamples() throws InterruptedException
	{
		launchActitime();
		
		//Creating an instance of By class using the xpath static method
		By b = By.xpath("//input[@id='username']");
		
		// Creating an instance of WebElement type
		WebElement username = driver.findElement(b);		
		
		// Using the SendKeys method on WebElement
		username.sendKeys("admin");
		
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		
		
		driver.findElement(By.id("keepLoggedInCheckBox")).click();
		
		driver.findElement(By.name("remember")).click();
		
		String text = driver.findElement(By.linkText("actiTIME Inc.")).getText();
		
		System.out.println(text);
		
		String text1 = driver.findElement(By.partialLinkText("actiTIME Inc.")).getText();
		
		
		System.out.println(text1);
		
		
		
		
		
	}
	
}
