package com.selenium.tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.library.CommonLibrary;

public class Login extends BaseClass{	
	
	@Test
	public static void login_001() throws Exception
	{			
		String userName = getTestData("Login", "UserNameValid_EditBox");
		String password = getTestData("Login", "Password_EditBox");	
		
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		result=false;
		
		Assert.assertTrue(result, "Login_001 failed!!");
		
	
	}
	
	
	@Test(dataProvider = "logindata", dataProviderClass = com.selenium.dataproviders.TestDataProvider.class)
	public static void login_002(String userName,String password) throws Exception
	{		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		Assert.assertTrue(result, "Login_002 Faild!!");
		
	}	
	

}
