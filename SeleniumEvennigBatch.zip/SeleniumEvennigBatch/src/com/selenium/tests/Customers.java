package com.selenium.tests;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.library.CommonLibrary;

public class Customers extends BaseClass{
	
	
	

	@Test
	public static void createCustomer_001() throws Exception
	{
		
		String userName = getTestData("Login", "UserNameValid_EditBox");
		String password = getTestData("Login", "Password_EditBox");
		
		String customerName = "AutoCustomer_"+System.currentTimeMillis();
		
		//launchBrowser();		
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		
		// Creating new customer	
		
		CommonLibrary.selectModule("Tasks");
		
		Thread.sleep(2000);
		
		clickWebElement(getWebElementFromLocator("Tasks", "ProjectsAndCustomer_Link"));
		
		clickWebElement(getWebElementFromLocator("Tasks", "CreateCustomer_Button"));
		
		enterTextInTextBox(getWebElementFromLocator("Customer", "CustomerName_EditBox"), customerName);
		
		clickWebElement(getWebElementFromLocator("Customer", "CreateCustomer_Button"));
		
		String successMessage = getWebElementFromLocator("Tasks", "SuccessMessage_Text").getText();
		
		boolean result1 = successMessage.contains(customerName);
		
		Assert.assertTrue(result1, "The customer cold not be created");
		 
				
		
	}
	

}
