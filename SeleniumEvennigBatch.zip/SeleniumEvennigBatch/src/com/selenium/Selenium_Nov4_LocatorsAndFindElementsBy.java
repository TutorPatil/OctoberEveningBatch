package com.selenium;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Selenium_Nov4_LocatorsAndFindElementsBy {
	
	static WebDriver driver = null;
	static String url = "https://erail.in/";	
	//static String url = https://demo.actitime.com;

	public static void main(String[] args) throws InterruptedException {
		
		dropDownExample1();		

	}
	
	public static void launchActitime()
	{
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
		
		driver = new ChromeDriver();		
		
		driver.get(url);
	}
	
	public static void locatorExamples() 
	{
		launchActitime();
		
		//Creating an instance of By class using the xpath static method
		By b = By.xpath("//input[@id='username']");
		
		// Creating an instance of WebElement type
		WebElement username = driver.findElement(b);		
		
		// Using the SendKeys method on WebElement
		username.sendKeys("admin");
		
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		
		
		driver.findElement(By.id("keepLoggedInCheckBox")).click();
		
		driver.findElement(By.name("remember")).click();
		
		String text = driver.findElement(By.linkText("actiTIME Inc.")).getText();
		
		System.out.println(text);
		
		String text1 = driver.findElement(By.partialLinkText("actiTIME Inc.")).getText();
		
		
		System.out.println(text1);
		
	}
	
	public static void selectItemFromQuotaDropDown(WebElement dropdown,String item) {
		
	
		
		Select comboSelect = new Select(dropdown);
		
		comboSelect.selectByVisibleText(item);
		
		
		
	}
	
	
	public static void dropDownExample1() throws InterruptedException
	{
		
		launchActitime();
		
		WebElement dropdown = driver.findElement(By.id("cmbQuota"));
		
		Select comboSelect = new Select(dropdown);
		
		//comboSelect.selectByVisibleText("Tatkal");
		
		selectItemFromQuotaDropDown(dropdown,"Tatkal");
		
		
		selectItemFromQuotaDropDown(dropdown,"Defence");
		
		
		Thread.sleep(2000);
		
		comboSelect.selectByIndex(5);
		
		Thread.sleep(2000);
		
		comboSelect.selectByValue("SS");	
		
		// Get the selected item from the dropdown
		String selectedItem = comboSelect.getFirstSelectedOption().getText();
		
		System.out.println(selectedItem);
		
		List<WebElement> items = comboSelect.getOptions();
		
		System.out.println(items.size());
		
		
		for(int x=0;x<items.size();x++)
		{
			System.out.println(items.get(x).getText());
			
		}
		
		
		
		closeBrowser();
		
		
		/*
		List<String> l = new ArrayList<String>();
		
		l.add("selenium");
		
		l.add("testing");
		
		l.add("automation");
		*/
		
		
		
		
	}
	
	public static void closeBrowser()
	{
		driver.quit();
	}

}
