package com.selenium;

public interface WebElementTest {
	
	 void click();
	
	

}
