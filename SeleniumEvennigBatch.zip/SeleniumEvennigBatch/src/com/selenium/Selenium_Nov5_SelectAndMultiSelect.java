package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Selenium_Nov5_SelectAndMultiSelect {
	
	public static void main(String[] args) {
		dropDownExample1();
	}
	
	public static void dropDownExample1()
	{
		CommonLibrary.launchBrowser();
		
		WebElement dropdown = CommonLibrary.driver.findElement(By.id("cmbQuota"));
		
		Select comboSelect = new Select(dropdown);
		
		comboSelect.selectByVisibleText("Tatkal");
		
		CommonLibrary.closeBrowser();
		
		
		
	}
	
	

}
