package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumBasics {
	
	public static void main(String[] args) throws InterruptedException {
		
				
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();		
		
		driver.get("https://demo.actitime.com");
		
		System.out.println(driver.getCurrentUrl());
		
		System.out.println(driver.getTitle());
		
		By b = By.xpath("//input[@id='username']");
		
		WebElement webelement = driver.findElement(b);
		
		webelement.sendKeys("admin");
		
		/*
		
		By b1 = By.xpath("//input[@name='pwd']");
		
		WebElement password = driver.findElement(b1);
		
		password.sendKeys("manager");
		
		*/
		
		driver.findElement(By.xpath("//input[@name='pwd']")).clear();
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//input[@name='pwd']")).clear();
		
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		
		WebElement checkBox = driver.findElement(By.xpath("//input[@id='keepLoggedInCheckBox']"));
		
		checkBox.click();
		
		boolean isChecked = checkBox.isSelected();
		
		System.out.println(" The check box is checked "+isChecked);	
		
		
		boolean isEnabled = driver.findElement(By.xpath("//a[@id='loginButton']")).isEnabled();
		
		System.out.println(" The login button is enabled "+isEnabled);
				
		
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();
		
		Thread.sleep(5000);
		
		boolean isLoggedin = driver.findElement(By.xpath("//a[@class='logout']")).isDisplayed();
		
		
		if (isLoggedin)
		{
			System.out.println("successfully logged in Test Case Login-001 is Passed");
		}
		else
		{
			System.out.println("Could not login to actitime-- Test Case Login-001 is Failed!!");
		}
			
		
		
		driver.quit();
		
		String s = "Selenium";
		
		s.toUpperCase().length();
		
		
		
		//System.out.println(driver.getPageSource());
		
		//driver.quit();

	}

}
