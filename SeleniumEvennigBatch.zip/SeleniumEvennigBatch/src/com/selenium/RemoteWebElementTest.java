package com.selenium;

public class RemoteWebElementTest implements WebElementTest{

	public void click() {
		System.out.println("clicking on the button");
		
	}
	

}
