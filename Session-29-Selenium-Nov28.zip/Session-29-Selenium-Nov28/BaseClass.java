package com.selenium.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.google.common.io.Files;

public class BaseClass {

	
	public static WebDriver driver = null;	
	
	
	public static void launchBrowser(String url)
	{
		System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");
		
		driver = new ChromeDriver();		
		
		driver.get(url);
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	
	@BeforeMethod(alwaysRun=true)
	public static void launchBrowser() throws IOException
	{
		
		String url = getConfigData("url");
		
		String browser = getConfigData("browser");
		
		if (browser.equalsIgnoreCase("chrome"))
		{
		
			System.setProperty("webdriver.chrome.driver", "./utilities/chromedriver.exe");		
			driver = new ChromeDriver();
		
		}
		
		else if (browser.equalsIgnoreCase("firefox"))
		{
		
			System.setProperty("webdriver.gecko.driver", "./utilities/geckodriver.exe");		
			driver = new FirefoxDriver();
		
		}
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	
		
		
		
		driver.get(url);
	}
	
	@AfterMethod(alwaysRun=true)
	public static void closeBrowser()
	{
		driver.close();
	}
	
	public static void captureScreenshot(String fileName)
	
	{		
		File src = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		File dest = new File("./results/"+fileName+".png");
			
		try {
			Files.copy(src, dest);
		} catch (IOException e) {			
			e.printStackTrace();
		}
		
		
	}
	
	public static String getConfigData(String key) throws IOException
	{
		String value = "";
		
		File f = new File("./data/config.properties");
		FileInputStream fis = new FileInputStream(f);
		
		Properties prop = new Properties();
		prop.load(fis);
		
		
		value = prop.getProperty(key);
		
		
		return value;	
		
	}
	
	public static WebElement getWebElementFromLocator(String pageName, String elementName) throws IOException
	{
		WebElement element = null;
		
		By b = getLocator(pageName,elementName);
		
		element = driver.findElement(b);
		
		return element;
		
		
	}
	
	public static By getLocator(String pageName, String elementName) throws IOException
	{
		By b = null;
		
		String locator = getLocatorData(pageName,elementName);
		
		//System.out.println(locator);
		String[] locatorDetails = locator.split("#");
		//System.out.println();
		
		String locatorType = locatorDetails[0];
		String locatorName = locatorDetails[1];
		
		
		if(locatorType.equalsIgnoreCase("id"))
		{		
			b  = By.id(locatorName);		
		
		}
		else if (locatorType.equalsIgnoreCase("name"))
		{
			b  = By.name(locatorName);
		}
		else if (locatorType.equalsIgnoreCase("xpath"))
		{
			b  = By.xpath(locatorName);
		}
			
		
		return b;
	}
	
	public static String getLocatorData(String pageName, String elementName) throws IOException
	{
		String locator = "";
		String locatorType ="";
		File f = new File("./data/locatordata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the Object of the WorkBook
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		//Getting the work sheet
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		//To fetch the number of used rows in the current sheet
		int rows = ws.getLastRowNum();
		
		for (int i=1;i<=rows;i++)
		{
			String page = ws.getRow(i).getCell(0).getStringCellValue();
			String element = ws.getRow(i).getCell(1).getStringCellValue();
			
			if(pageName.equalsIgnoreCase(page) && elementName.equalsIgnoreCase(element))
			{
				 locator = ws.getRow(i).getCell(3).getStringCellValue();
				 locatorType = ws.getRow(i).getCell(2).getStringCellValue();
				 break;			}					
		}		
		wb.close();		
		return locatorType+"#"+locator;
	}
	
	

	public static String getTestData(String pageName, String elementName) throws IOException
	{
		String data = "";		
		File f = new File("./data/testdata.xlsx");		
		FileInputStream fio = new FileInputStream(f);
		
		// Creating the Object of the WorkBook
		XSSFWorkbook wb = new XSSFWorkbook(fio);
		
		//Getting the work sheet
		XSSFSheet ws = wb.getSheet("Sheet1");
		
		//To fetch the number of used rows in the current sheet
		int rows = ws.getLastRowNum();		
		for (int i=1;i<=rows;i++)
		{
			String page = ws.getRow(i).getCell(0).getStringCellValue();
			String element = ws.getRow(i).getCell(1).getStringCellValue();
			
			if(pageName.equalsIgnoreCase(page) && elementName.equalsIgnoreCase(element))
			{
				data = ws.getRow(i).getCell(2).getStringCellValue();
				 break;			}					
		}		
		wb.close();		
		return data;
	}
	
	public static void enterTextInTextBox(WebElement element, String text)
	{
		element.sendKeys(text);
		
	}
	
	public static void clickWebElement(WebElement element)
	{
		element.click();
	}
	
	
	public static void writeResultsToFile(String testCaseName, String testCaseResult) throws IOException	
	{
		File f = new File("./results/results.txt");
		
		FileWriter fw = new FileWriter(f,true);
		
		fw.write(testCaseName+"---"+testCaseResult+"\r\n");
		
		fw.flush();
		fw.close();
		
		
	}
	
	public static void prepareLocatorMap()
	{
		
		
		
	}
	



}
