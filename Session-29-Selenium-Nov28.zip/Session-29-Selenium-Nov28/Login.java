package com.selenium.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.selenium.base.BaseClass;
import com.selenium.library.CommonLibrary;

public class Login extends BaseClass{
	
		
	@Test
	public static void login_001() throws Exception
	{
		String userName = getTestData("Login", "UserNameValid_EditBox");
		String password = getTestData("Login", "Password_EditBox");	
		
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		
		Assert.assertTrue(result, "Login_001 failed!!");
		writeResultsToFile("login_001", "Pass");
		
		int expCount = 10;
		
		int actualCount =  8;
		
		boolean count = (expCount == actualCount);
		
		Assert.assertTrue(count, "The actual count is not as expected");
		
		System.out.println("After the assertion");
		
		//Assert.assertFalse(count, "sdsdadadaad");
		//Assert.assertEquals(expCount, actualCount);
		
		
	}
	
	@Test
	public static void login_002() throws Exception
	{
		String userName = getTestData("Login", "UserNameValid_EditBox");
		String password = getTestData("Login", "Password_EditBox");
		
	
		
		boolean result = CommonLibrary.launchLoginToActiTime(userName, password);
		result=false;
		
		Assert.assertTrue(result, "Login_002 Faild!!");
		
			
		
	}

}
