package com.corejava.classes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Tester {

	public static void main(String[] args) {	

		Mobile m2 = new Mobile(2, 8000, 10);
		Mobile m1 = new Mobile(1, 5000, 5);
		Mobile m3 = new Mobile(3, 10000, 12);
		
		List<Mobile> mList = new ArrayList<Mobile>();
		
		mList.add(m1);
		mList.add(m2);
		mList.add(m3);
		
		/*
		Collections.sort(mList);
		
		for(Mobile m : mList)
		{
			System.out.println(m);
		}
		
		*/
		
		Comparator<Mobile> comp = new Comparator<Mobile>()
		{

			@Override
			public int compare(Mobile m1, Mobile m2) {
				
				if(m1.getCamaraPix() > m2.getCamaraPix())
					return 1;
				else if(m1.getCamaraPix() < m2.getCamaraPix())
					return -1;
				else
					return 0;
				
			}
			
			
		};
		
		Collections.sort(mList, comp);
		
		for(Mobile m : mList)
		{
			System.out.println(m);
		}
		
		
		
		
		
		
		
		
		
	}
}
