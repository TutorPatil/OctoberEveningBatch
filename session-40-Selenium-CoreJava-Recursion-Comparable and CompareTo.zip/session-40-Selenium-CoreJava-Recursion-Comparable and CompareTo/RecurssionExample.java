package com.corejava.classes;

public class RecurssionExample {
	
	public static void main(String[] args) {
		System.out.println(findFact(5));
	}
	
	
	public static void printNumbers(int x)
	{
		
		if( x >= 0)
			printNumbers(x-1);
		System.out.print(x+" ");
		
		
	}
	
	public static int findFactorial(int num)
	{
		if ( num <= 1)
			return 1;
		else
			return (num  * (findFactorial(num - 1)));
		
		
	}
	
	public static int getFactorial(int num)
	{
		int fact = 1;
		while ( num >= 1)
		{
			fact = (fact * num);
			num--;
			
		}
		
		return fact;
	}
	
	
	public static void showNumbers(int x)
	{
		if(x >= 0)
			showNumbers(x-1);
		System.out.print(x+" ");
			
			
		
	}

	
	public static void method1()
	{
		System.out.println("inside method 1");
		method2();
	}
	
	public static void method2()
	{
		System.out.println("inside method 2");
		method3();
	}
	
	public static void method3()
	{
		System.out.println("inside method 3");
	}
	
	public static int findFact(int num)
	{
		if(num == 1)
			return 1;
		return ( num *  findFact(num-1));
		
	}
	
}
