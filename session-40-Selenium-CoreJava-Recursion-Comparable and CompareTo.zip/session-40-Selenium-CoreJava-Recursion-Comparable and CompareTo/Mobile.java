package com.corejava.classes;

//public class Mobile implements Comparable<Mobile>{
	
	public class Mobile {

	private int ram;
	private double cost;
	private int camaraPix;
	
	@Override
	public String toString() {
		return "Mobile [ram=" + ram + ", cost=" + cost + ", camaraPix=" + camaraPix + "]";
	}

	public Mobile(int ram, double cost, int camaraPix) {
		super();
		this.ram = ram;
		this.cost = cost;
		this.camaraPix = camaraPix;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public int getCamaraPix() {
		return camaraPix;
	}

	public void setCamaraPix(int camaraPix) {
		this.camaraPix = camaraPix;
	}

	/*
	public int compareTo(Mobile m) {
			
		if(this.getRam() > m.getRam() )
				return -11;
		else if	(this.getRam() < m.getRam())
			return 1;
		else
			return 0;
		
	}
	
	*/
	
	
}
