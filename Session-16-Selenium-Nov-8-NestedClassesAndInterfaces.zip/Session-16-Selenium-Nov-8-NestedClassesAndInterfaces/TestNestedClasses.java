package com.selenium;

public class TestNestedClasses {

	public static void main(String[] args) {
		
		Outer  out = new Outer();
		out.outerAge = 10;	
		TestInterface t;
		
		
		out.in2.innerAge = 10;
		
		
		out.in2.printInnerAge();
		
		
		
		out.printOuterAge();
		
		// Syntax for creating the instance of Inner class
		Outer.Inner in = out.new Inner();
		
		in.innerAge = 5;
		
		in.printInnerAge();	
		
		
		// Creating the instance of the static innerclass
		
		Outer.InnerStatic instat = new Outer.InnerStatic();
		
		System.out.println(instat.staticAge);
		
		//System.out.println(instat.mobile);
				
		System.out.println(Outer.InnerStatic.name);
		
	/*	
		Test123 t = new Test123();
		
		t.click();
*/
		 t = new TestInterface() {
			
			
			public void click() {
				System.out.println("clicking using annonymous");
				
			}
			

		
			public void sendKeys() {
				System.out.println("send Keys method");
				
			}
		};
		
		t.click();
		t.sendKeys();
	}

}
