package com.selenium;

public class Test123 implements TestInterface{

	
	public void click() {
		System.out.println("clicking on the button");
		
	}

	
	public void sendKeys() {
		System.out.println("sendkeys method");
		
	}

}
