package com.selenium;

public interface OuterInterface {
	
	void click();
	
	InnerInterface manage();
	
	String getLength();
	
	interface InnerInterface{
		
		void innerClick();
		
	}
	

}
