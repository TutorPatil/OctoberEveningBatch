package com.selenium;

public interface TestInterface {
	
	public abstract void click();	
	public abstract void sendKeys();
	
	
	

}
