package com.selenium;

public class NestedInterface implements OuterInterface{

	
	public void click() {
	
		
	}

	
	public InnerInterface manage() {		
		return null;
	}

	
	public String getLength() {
		
		return "Selenium";
	}
	
	public static void main(String[] args) {
		NestedInterface  ni = new NestedInterface();
		System.out.println(ni.getLength().length());
		
		ni.manage().innerClick();
		
		InnerInterface ii = ni.manage();
		
		ii.innerClick();
		
		
	}
	

}
