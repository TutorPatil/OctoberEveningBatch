package com.selenium;

public class Outer {
	
	int outerAge;
	String s = "selenium";
	static String course = "automation";
	
	Inner in2 = new Inner();
	
	InnerPrivate ip = new InnerPrivate();
	
	
	public void printOuterAge()
	{
		//Inner in = new Inner();
		//in.innerAge = 5;
		//in.printInnerAge();
		System.out.println(ip.privateAge);
		System.out.println(outerAge);
	}	
	
	class Inner{
		int innerAge;
		public void printInnerAge()
		{
			
			System.out.println(innerAge);
			//System.out.println("====="+outerAge);
		}
		
		class Inner1{
			int inner1Age = 2;
			
		}		
		
	}
	
	
	static class InnerStatic{
		
		int staticAge = 20;
		
		private int mobile = 20;
		
		static String name="Ramu";	
		
		
		
	}
	
	private class InnerPrivate{
		
		private int privateAge = 6;
		
	}
	
}
