package com.selenium.tests;

import com.selenium.base.BaseClass;

public class Customers extends BaseClass{
	
	
	public static void customer_001()
	{
		
		
	}

}
