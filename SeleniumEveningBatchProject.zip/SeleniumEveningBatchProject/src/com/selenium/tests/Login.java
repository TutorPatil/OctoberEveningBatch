package com.selenium.tests;

import com.selenium.base.BaseClass;

public class Login extends BaseClass{
	
	
	public static void login_001()
	{
		
		
	}
	
	
	public static void login_002()
	{
		
		
	}


}
