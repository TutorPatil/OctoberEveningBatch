package com.selenium.library;

import com.selenium.base.BaseClass;

public class CommonLibrary extends BaseClass{

}
