package com.selenium.base;

import org.openqa.selenium.WebDriver;

public class BaseClass {
	
	public static WebDriver driver = null;
	
	
	public void launchBrowser()
	{
		
		
	}
	

}
