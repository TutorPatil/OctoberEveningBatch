package com.selenium.tests;

import java.io.IOException;

import org.testng.annotations.Test;

import com.selenium.base.BaseClass;

public class RunCommands extends BaseClass{
	
	
	@Test
	public static void runCommandsUsingJava() throws IOException, InterruptedException
	{
		//String[] cmd = {"cmd.exe","/c","taskkill /f /im notepad.exe&taskkill /f /im excel.exe"};
		
		Runtime rt = Runtime.getRuntime();		
		//rt.exec("taskkill /f /im notepad.exe&taskkill /f /im excel.exe");
		
		//rt.exec(cmd);
		
		//rt.exec("calc");
		
		Thread.sleep(4000);
		
		
		rt.exec("taskkill /f /im calculator.exe");
		
		
	}

}
