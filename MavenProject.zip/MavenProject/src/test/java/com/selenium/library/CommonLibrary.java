package com.selenium.library;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.selenium.base.BaseClass;

public class CommonLibrary extends BaseClass{
	
		
	
	public static boolean launchLoginToActiTime(String username, String password) throws Exception
	{
		enterTextInTextBox(getWebElementFromLocator("Login","UserName_EditBox"), username);
		enterTextInTextBox(getWebElementFromLocator("Login","Password_EditBox"), password);
		clickWebElement(getWebElementFromLocator("Login","Ok_Button"));
		
		
		
		WebElement logoutLink = getWebElementFromLocator("Home","Logout_Link");
		
		boolean result = logoutLink.isDisplayed();
		
		//logoutLink.click();
		
		return result;
		
	}
	
	
	
	public static boolean invalidLoginTest(String username, String password) throws Exception
	{
		boolean result = false;
				
		getWebElementFromLocator("Login","UserName_EditBox").clear();
		enterTextInTextBox(getWebElementFromLocator("Login","UserName_EditBox"), username);
		enterTextInTextBox(getWebElementFromLocator("Login","Password_EditBox"), password);
		clickWebElement(getWebElementFromLocator("Login","Ok_Button"));
		
		Thread.sleep(2000);
		
		String errorText = getWebElementFromLocator("Login","ErrorMessage_Text").getText();
		
		if (errorText.contains("Username or Password is invalid. Please try again."))
		{
			result = true;
			
		}
		
		return result;
		
	}


	public static void selectModule(String moduleName) throws IOException
	{
		String module = getLocatorData("Home", "TabName_Menu");		
		String[] modules = module.split("#");		
		String moduleXpath = modules[1].replace("--TEXTTOREPLACE--", moduleName);		
		driver.findElement(By.xpath(moduleXpath)).click();
		
	}
	

}
